article_title: Evaluating Jev for biomedical evidence screening: discrimination, calibration and high-recall workload
journal: Health Information Science and Systems
author: Xiang Chen
corresponding_author_affiliation: Clinical Medical College, North China University of Science and Technology, Tangshan, Hebei, China
corresponding_author_email: chenxiang1029@stu.ncst.edu.cn

Online Resource 2. Complete-precision supplementary analysis tables. Original fields and values are unchanged; article metadata columns are added. Tables S1-S10 and interpretation are in Online Resource 1. Numeric metrics are fractions, not percentages. Empty values are not zero. No complete prediction dataset, retraining pipeline or dependency lockfile is included.
